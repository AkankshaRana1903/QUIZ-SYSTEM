import java.util.*;

public class OnlineQuiz {
    static class Player {
        String name;
        int score;
        long totalResponseTime; 

        Player(String name) {
            this.name = name;
            this.score = 0;
            this.totalResponseTime = 0;
        }

        void addScore(int points, long responseTime) {
            this.score += points;
            this.totalResponseTime += responseTime;
        }

        @Override
        public String toString() {
            return name + " - Score: " + score + ", Total Response Time: " + totalResponseTime + "ms";
        }
    }
    private static final int TOTAL_QUESTIONS = 10;
    private static final int POINTS_PER_CORRECT_ANSWER = 10;
    private int numberOfPlayers;
    private Queue<Player> playerQueue;
    private Map<String, List<String>> questionOptionsMap;
    private Map<String, Integer> questionAnswerMap;
    private Stack<String> questionHistory;
    private PriorityQueue<Player> leaderboard;
    private Scanner scanner;
    private List<String> questionsList;

    public OnlineQuiz() {
        playerQueue = new LinkedList<>();
        questionOptionsMap = new HashMap<>();
        questionAnswerMap = new HashMap<>();
        questionHistory = new Stack<>();
        scanner = new Scanner(System.in);
        leaderboard = new PriorityQueue<>((p1, p2) -> {
            if (p2.score != p1.score) {
                return p2.score - p1.score;
            } else {
                return Long.compare(p1.totalResponseTime, p2.totalResponseTime);
            }
        });

        questionsList = new ArrayList<>();
    }

    private void initializeQuestions() {
        addQuestion("What is the capital of France?",
                Arrays.asList("Berlin", "Madrid", "Paris", "Rome"), 3);
        addQuestion("What is 2 + 2?",
                Arrays.asList("3", "4", "5", "6"), 2);
        addQuestion("Who wrote 'Romeo and Juliet'?",
                Arrays.asList("Shakespeare", "Dickens", "Hemingway", "Tolkien"), 1);
        addQuestion("What is the boiling point of water in Celsius?",
                Arrays.asList("90", "100", "110", "120"), 2);
        addQuestion("What is the largest planet in our solar system?",
                Arrays.asList("Earth", "Mars", "Jupiter", "Saturn"), 3);
        addQuestion("What is the chemical symbol for gold?",
                Arrays.asList("Ag", "Au", "Pb", "Fe"), 2);
        addQuestion("Who painted the Mona Lisa?",
                Arrays.asList("Van Gogh", "Da Vinci", "Picasso", "Rembrandt"), 2);
        addQuestion("What is the square root of 64?",
                Arrays.asList("6", "7", "8", "9"), 3);
        addQuestion("What year did the Titanic sink?",
                Arrays.asList("1905", "1912", "1920", "1930"), 2);
        addQuestion("What is the currency of Japan?",
                Arrays.asList("Dollar", "Euro", "Yen", "Won"), 3);
    }

    private void addQuestion(String question, List<String> options, int correctOption) {
        questionsList.add(question);
        questionOptionsMap.put(question, options);
        questionAnswerMap.put(question, correctOption);
    }

    private void registerPlayers() {
        System.out.print("Enter number of players: ");
        while (true) {
            String input = scanner.nextLine().trim();
            try {
                numberOfPlayers = Integer.parseInt(input);
                if (numberOfPlayers < 1) {
                    System.out.print("Number of players must be at least 1. Enter again: ");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Enter a valid number of players: ");
            }
        }

        System.out.println("Enter names of " + numberOfPlayers + " players:");
        for (int i = 1; i <= numberOfPlayers; i++) {
            System.out.print("Player " + i + " name: ");
            String name = scanner.nextLine().trim();
            while (name.isEmpty()) {
                System.out.print("Name cannot be empty. Enter Player " + i + " name: ");
                name = scanner.nextLine().trim();
            }
            Player player = new Player(name);
            playerQueue.offer(player);
            leaderboard.offer(player);
        }
    }

    private void startQuiz() {
        System.out.println("\nStarting the MCQ quiz with " + numberOfPlayers + " players and 10 questions...\n");

        int questionNumber = 1;
        for (String question : questionsList) {
            questionHistory.push(question);
            boolean answeredCorrectly = false;
            System.out.println("Question " + questionNumber + ": " + question);
            List<String> options = questionOptionsMap.get(question);
            for (int i = 0; i < options.size(); i++) {
                System.out.println((i + 1) + ". " + options.get(i));
            }

            int attempts = 0;
            final int maxAttempts = numberOfPlayers;

            Queue<Player> tempQueue = new LinkedList<>(playerQueue);

            while (attempts < maxAttempts && !answeredCorrectly) {
                Player currentPlayer = tempQueue.poll();
                if (currentPlayer == null) {
                    break;
                }
                System.out.println(currentPlayer.name + ", your turn to answer. (Enter option number or press Enter to skip)");

                long startTime = System.currentTimeMillis();
                String input = scanner.nextLine().trim();
                long responseTime = System.currentTimeMillis() - startTime;

                if (input.isEmpty()) {
                    System.out.println(currentPlayer.name + " skipped the question.");
                } else {
                    try {
                        int selectedOption = Integer.parseInt(input);
                        if (selectedOption == questionAnswerMap.get(question)) {
                            System.out.println("Correct answer!");
                            leaderboard.remove(currentPlayer);
                            currentPlayer.addScore(POINTS_PER_CORRECT_ANSWER, responseTime);
                            leaderboard.offer(currentPlayer);
                            answeredCorrectly = true;
                        } else {
                            System.out.println("Wrong answer.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid option number.");
                    }
                }
                attempts++;
            }

            if (!answeredCorrectly) {
                System.out.println("No one answered correctly. Moving to next question.\n");
            } else {
                System.out.println();
            }

            questionNumber++; 
        }
    }

    private void displayLeaderboard() {
        System.out.println("Final Leaderboard:");
        List<Player> sortedPlayers = new ArrayList<>(leaderboard);
        sortedPlayers.sort((p1, p2) -> {
            if (p2.score != p1.score) {
                return p2.score - p1.score;
            } else {
                return Long.compare(p1.totalResponseTime, p2.totalResponseTime);
            }
        });

        int rank = 1;
        for (Player player : sortedPlayers) {
            System.out.println(rank + ". " + player);
            rank++;
        }
    }

    public static void main(String[] args) {
        OnlineQuiz quiz = new OnlineQuiz();
        quiz.initializeQuestions();
        quiz.registerPlayers();
        quiz.startQuiz();
        quiz.displayLeaderboard();
    }
}
